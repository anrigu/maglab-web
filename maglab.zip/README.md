# maglab-web

Built using MERN stack

Heroku for API & Netlify for file processing

AWS for file storage